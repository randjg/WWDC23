//
//  LandingPageView.swift
//  JelajahSolo
//
//  Created by Randy Julian on 10/04/23.
//

import SwiftUI

struct LandingPageView: View {
    
    @State private var isActive = false
    @State private var angle: Double = 0
    
    var body: some View {
        NavigationView{
            ZStack {
                Image("Subject")
                    .resizable()
                    .frame(maxWidth: .infinity)
                    .frame(maxHeight: .infinity)
                    .scaledToFit()
                    .offset(y:400)
                    .ignoresSafeArea()
                
                
                Image("sky")
                    .resizable()
                    .frame(maxWidth: 1300)
                    .frame(maxHeight: 1300)
                    .opacity(0.6)
                    .offset(y:-250)
                
                
                VStack {
                    ZStack{
                        Image("titleLanding")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 400, height: 400)
                            .rotationEffect(Angle.degrees(angle))
                            .onAppear{
                                withAnimation(.linear(duration: 1).repeatForever()){
                                    angle = 5
                                }
                            }
                    }

                    HStack{
                        Spacer()
                        Button(action: {
                            }, label: {
                                NavigationLink(destination: HomePageView(), isActive: $isActive){
                                    HStack{
                                        Text("Enter")
                                    }
                                    .padding()
                                    .frame(maxWidth: 200)
                                    .background(.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(100)
                                }
                            }).hidden()
                        Spacer()
                    }
                    .onAppear{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2){
                            isActive = true
                        }
                    }
                    Spacer()
                }
                
            }
            .navigationBarTitle("")
            .navigationBarHidden(true)
            .background(.blue .opacity(0.3))
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
        
    }
}

