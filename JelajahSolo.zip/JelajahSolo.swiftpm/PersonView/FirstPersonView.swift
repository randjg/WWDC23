//
//  FirstPersonView.swift
//  JelajahSolo
//
//  Created by Randy Julian on 10/04/23.
//

import SwiftUI

struct FirstPersonView: View {
    var body: some View {
        VStack{
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.yellow).opacity(1)
                    .frame(width: 500, height: 170)

                HStack {
                    Image("putri")
                        .resizable()
                        .frame(width: 170, height: 170)
                    
                    Text("Hello, my name is Putri! I am 18 years old.")
                        .font(.title)
                        .frame(maxWidth: 400)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: 450)
                .padding()
            }
            
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.yellow).opacity(1)
                    .frame(width: 500, height: 350)
                
                VStack{
                    VStack {
                        Text("My hobby is dancing Solo traditional dance. The name of the traditional dance below is 'Tari Serimpi'. The number of dancers in Tari Serimpi is four women. The meaning of this dance is politeness and gentleness.")
                            .font(.system(size: 18))
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: 450)
                    }

                    Image("putri2")
                        .resizable()
                        .frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .cornerRadius(10)
                        .scaledToFit()
                }
                .padding()
            }
            
        }
        .background(Image("bgBatik")
            .scaledToFill())
        
    }
}

struct FirstPersonView_Previews: PreviewProvider {
    static var previews: some View {
        FirstPersonView()
    }
}
