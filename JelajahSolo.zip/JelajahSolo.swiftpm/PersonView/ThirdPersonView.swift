//
//  ThirdPersonView.swift
//  JelajahSolo
//
//  Created by Randy Julian on 10/04/23.
//

import SwiftUI

struct ThirdPersonView: View {
    
    
    
    var body: some View {
//        ZStack {
//            Image("bgBatik")
//                .resizable()
//                .scaledToFill()
//                .scaleEffect(scale)
//                .animation(Animation.easeInOut(duration: 50.0), value: scale)
//
            VStack{
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(.yellow).opacity(1)
                        .frame(width: 500, height: 170)
                    
                    HStack {
                        Image("bambang")
                            .resizable()
                            .frame(width: 140, height: 170)
                        
                        Text("Hello, my name is Bambang! I am 57 years old.")
                            .font(.title)
                            .frame(maxWidth: 400)
                            .multilineTextAlignment(.center)
                    }
                    .padding()
                    .frame(maxWidth: 450)
                }
                
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(.yellow).opacity(1)
                        .frame(width: 500, height: 350)
                    
                    VStack{
                        VStack {
                            Text("I like to learn about traditional music especially 'Gamelan'. A gamelan refers to a type of musical ensemble that features a diverse range of instruments, including metallophones, xylophones, flutes, gongs, vocals, etc. Gamelan has been listed as an element of the intangible cultural heritage of humanity on the UNESCO Representative List on 2021.")
                                .font(.system(size: 17))
                                .multilineTextAlignment(.center)
                                .frame(maxWidth: 450)
                        }
                        
                        Image("bambang2")
                            .resizable()
                            .frame(width: 180, height: 180, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .cornerRadius(10)
                            .scaledToFit()
                        //                        .offset(x:-20)
                    }
                    .padding()
                }
            }
                        .background(Image("bgBatik"))
        }
//        }.onAppear{
//            self.scale = 2.0
//        }
    }


struct ThirdPersonView_Previews: PreviewProvider {
    static var previews: some View {
        ThirdPersonView()
    }
}

