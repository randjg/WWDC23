//
//  SecondPersonView.swift
//  JelajahSolo
//
//  Created by Randy Julian on 10/04/23.
//

import SwiftUI

struct SecondPersonView: View {
    var body: some View {
        VStack{
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.yellow).opacity(1)
                    .frame(width: 500, height: 170)

                HStack {
                    Image("joko")
                        .resizable()
                        .frame(width: 170, height: 170)
                    
                    Text("Hello, my name is Joko! I am 29 years old.")
                        .font(.title)
                        .frame(maxWidth: 400)
                        .multilineTextAlignment(.center)
                }
                .padding()
                .frame(maxWidth: 450)
            }
            
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.yellow).opacity(1)
                    .frame(width: 500, height: 350)
                
                VStack{
                    VStack {
                        Text("I like to exploring traditional foods! But my favorite was 'Dawet'. Dawet contains cendol (green rice flour jelly), black sticky rice, jackfruit, basil seeds and doused with savory coconut milk. It taste sweet and fresh")
                            .font(.system(size: 19))
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: 450)
                    }

                    Image("joko2")
                        .resizable()
                        .frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .cornerRadius(10)
                        .scaledToFit()
//                        .offset(x:-20)
                }
                .padding()
            }
            
        }
        .background(Image("bgBatik"))
    }
}

struct SecondPersonView_Previews: PreviewProvider {
    static var previews: some View {
        SecondPersonView()
    }
}

