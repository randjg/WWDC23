//
//  FourthPersonView.swift
//  JelajahSolo
//
//  Created by Randy Julian on 10/04/23.
//

import SwiftUI

struct FourthPersonView: View {
    var body: some View {
        VStack{
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.yellow).opacity(1)
                    .frame(width: 500, height: 170)

                HStack {
                    Image("dita")
                        .resizable()
                        .frame(width: 170, height: 170)
                    
                    Text("Hello, my name is Dita! I am 11 years old.")
                        .font(.title)
                        .frame(maxWidth: 400)
                        .multilineTextAlignment(.center)
                }
                .padding()
                .frame(maxWidth: 450)
            }
            
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.yellow).opacity(1)
                    .frame(width: 500, height: 350)
                
                VStack{
                    VStack {
                        Text("I like to play 'Dakon' with my fellas. Dakon consists of Board with minimum of 12 holes and small sapodilla seeds. Dakon can be played by two persons. There are many philosophical values of this game, like honesty, sportmanship, strategy, and many more.")
                            .font(.system(size: 19))
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: 450)
                    }

                    Image("dita2")
                        .resizable()
                        .frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .cornerRadius(10)
                        .scaledToFit()
//                        .offset(x:-20)
                }
                .padding()
            }
            
        }
        .background(Image("bgBatik"))
    }
}

struct FourthPersonView_Previews: PreviewProvider {
    static var previews: some View {
        FourthPersonView()
    }
}
