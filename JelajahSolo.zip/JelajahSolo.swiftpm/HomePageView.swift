//
//  HomePageView.swift
//  JelajahSolo
//
//  Created by Randy Julian on 10/04/23.
//

import AVFoundation
import SwiftUI

struct HomePageView: View {
    
    @State private var showModal1 = false
    @State private var showModal2 = false
    @State private var showModal3 = false
    @State private var showModal4 = false
    @State private var showSheet = false
    @State private var isTapped1 = false
    @State private var isTapped2 = false
    @State private var isTapped3 = false
    @State private var isTapped4 = false
    @State private var isTappedFinal = false

    @ViewBuilder
    var sheetView: some View{
        IntroView()
    }
    
    var body: some View {
        NavigationView{
            ZStack{
                Image("background2")
                    .resizable()
                    .scaledToFit()

                Text("")
                    .sheet(isPresented: $showSheet){
                        self.sheetView
                        
                        Button(action: {showSheet = false;  DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { self.isTapped1 = true}
                        }, label: {
                            HStack{
                                Text("Start")
                            }
                            .padding()
                            .frame(maxWidth: 200)
                            .background(.blue)
                            .foregroundColor(.white)
                            .cornerRadius(100)
                        })
                        .padding(.bottom, 50)
                    }
                    .onAppear{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                            self.showSheet = true;
                        }
                    }
                
                
                VStack {
                    HStack{
                        //person 1
                        if isTapped1{
                            VStack {
                                Image("putri")
                                    .resizable()
                                    .frame(width: 150, height: 150)
                                    .padding(.top, -120)
                                    .padding(.bottom, -10)
                                    .onAppear{
                                        AudioManager.instance.playSound()
                                    }

                                Button(action: {
                                    showModal1 = true
                                    ;DispatchQueue.main.asyncAfter(deadline: .now() + 7.0) { self.isTapped2 = true}
                                }, label: {
                                        Text("Hello, let's meet! 😊🙌🏼")
                                            .padding()
                                            .frame(width: 250, height: 40)
                                            .background(.blue)
                                            .foregroundColor(.white)
                                            .cornerRadius(100)
                                    })
                            }
                            .sheet(isPresented: $showModal1){
                                ModalView1()
                            }
                            .padding(.leading, 30)
                        }
                        Spacer()
                        
                        //person 2
                        if isTapped2{
                            VStack {
                                Image("joko")
                                    .resizable()
                                    .frame(width: 160, height: 160)
                                    .padding(.top, 100)
                                    .padding(.bottom, -10)
                                    .onAppear{
                                        AudioManager.instance.playSound()
                                    }
                                
                                Button(action: {
                                    showModal2 = true; DispatchQueue.main.asyncAfter(deadline: .now() + 7.0) { self.isTapped3 = true}
                                }, label: {
                                    Text("Get to know me more! 😜")
                                        .padding()
                                        .frame(width: 250, height: 40)      .background(.blue)
                                        .foregroundColor(.white)
                                        .cornerRadius(100)
                                })
                            }
                            .sheet(isPresented: $showModal2){
                                ModalView2()
                            }
                        }
                    }
                    .padding(.trailing, 30)
                        
                    HStack{
                        //person 3
                        if isTapped3{
                            VStack {
                                Image("bambang")
                                    .resizable()
                                    .frame(width: 120, height: 150)
                                    .padding(.top, -120)
                                    .padding(.bottom, -10)
                                    .onAppear{
                                        AudioManager.instance.playSound()
                                    }
                                
                                Button(action: {
                                    showModal3 = true; DispatchQueue.main.asyncAfter(deadline: .now() + 7.0) { self.isTapped4 = true}
                                }, label: {
                                    Text("How are you today? ☺️")
                                        .padding()
                                        .frame(width: 250, height: 40)      .background(.blue)
                                        .foregroundColor(.white)
                                        .cornerRadius(100)
                                })
                            }
                            .sheet(isPresented: $showModal3){
                                ModalView3()
                            }
                            
                            .padding(.leading, 15)
                        }
                        
                        Spacer()
                        
                        //person 4
                        if isTapped4{
                            VStack {
                                Image("dita")
                                    .resizable()
                                    .frame(width: 150, height: 150)
                                    .padding(.top, 100)
                                    .padding(.bottom, -10)
                                    .onAppear{
                                        AudioManager.instance.playSound()
                                    }
                                
                                Button(action: {
                                    showModal4 = true; DispatchQueue.main.asyncAfter(deadline: .now() + 7.0) { self.isTappedFinal = true}
                                }, label: {
                                    Text("Want to know about me? 😏")
                                        .padding()
                                        .frame(width: 280, height: 40)      .background(.blue)
                                        .foregroundColor(.white)
                                        .cornerRadius(100)
                                })
                            }
                            .sheet(isPresented: $showModal4){
                                ModalView4()
                            }
                        }
                    }
                    .padding(.trailing, 15)
                    .padding()
                        
                }
            }
            .background(.white)
        }
        
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)

        if isTappedFinal{
            HStack{
                Spacer()
                Button(action: {
                }, label: {
                    NavigationLink(destination: QuizView()){
                        HStack{
                            Text("Let's Take the Quiz! 🥳🎉")
                        }
                        .padding()
                        .frame(maxWidth: 280)
                        .background(.blue)
                        .foregroundColor(.white)
                        .cornerRadius(100)
                    }
                })
                Spacer()
            }
        }
        
    }
        
}

struct ModalView1: View{
    
    @Environment(\.presentationMode) var presentation
    
    var body: some View{
        FirstPersonView()
            Button(action: {presentation.wrappedValue.dismiss()
                
            }, label: {
                Text("Nice to meet you, Putri ☺️")
                    .padding()
                    .background(.blue)
                    .cornerRadius(50)
                    .foregroundColor(.white)
            })
    }
}

struct ModalView2: View{
    
    @Environment(\.presentationMode) var presentation
    
    var body: some View{
        SecondPersonView()
        Button(action: {presentation.wrappedValue.dismiss()
            
        }, label: {
            Text("Nice to meet you, Joko ☺️")
                .padding()
                .background(.blue)
                .cornerRadius(50)
                .foregroundColor(.white)
        })
    }
}

struct ModalView3: View{
    
    @Environment(\.presentationMode) var presentation
    
    var body: some View{
        ThirdPersonView()
        Button(action: {presentation.wrappedValue.dismiss()
            
        }, label: {
            Text("Nice to meet you, Bambang ☺️")
                .padding()
                .background(.blue)
                .cornerRadius(50)
                .foregroundColor(.white)
        })
    }
}

struct ModalView4: View{
    
    @Environment(\.presentationMode) var presentation
    
    var body: some View{
        FourthPersonView()
        Button(action: {presentation.wrappedValue.dismiss()
            
        }, label: {
            Text("Nice to meet you, Dita ☺️")
                .padding()
                .background(.blue)
                .cornerRadius(50)
                .foregroundColor(.white)
        })
    }
}




