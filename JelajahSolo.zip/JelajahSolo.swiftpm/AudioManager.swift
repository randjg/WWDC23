//
//  AudioManager.swift
//  JelajahSolo
//
//  Created by Randy Julian on 18/04/23.
//

import AVFoundation

class AudioManager{
    static let instance = AudioManager()
    var player: AVAudioPlayer!

    func playSound(){
        guard let url = Bundle.main.url(forResource: "sound", withExtension: "mp3") else { return }
        
        do{
            player = try AVAudioPlayer(contentsOf: url)
            player.numberOfLoops = 1
            player.play()
        } catch{
            print("error")
        }
    }
}
