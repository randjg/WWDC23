//
//  FinalView.swift
//  JelajahSolo
//
//  Created by Randy Julian on 10/04/23.
//

import SwiftUI

struct FinalView: View {
    
    var body: some View {
        VStack {
            Text("Congrats you have done your Quiz! 🥳\n")
                .font(.largeTitle)
                .foregroundColor(.white)
            Text("I hope you gain a new knowledge about Solo 👋🏼")
                .font(.largeTitle)
                .foregroundColor(.white)

            HStack{
                Spacer()
                Button(action: {
                    }, label: {
                        NavigationLink(destination: LandingPageView()){
                            HStack{
                                Text("Back")
                            }
                            .padding()
                            .frame(maxWidth: 200)
                            .background(.blue)
                            .foregroundColor(.white)
                            .cornerRadius(100)
                        }
                    })
                Spacer()
            }
        }
        .frame(maxWidth: 500)
        .multilineTextAlignment(.center)

    }
}

struct FinalView_Previews: PreviewProvider {
    static var previews: some View {
        FinalView()
    }
}
