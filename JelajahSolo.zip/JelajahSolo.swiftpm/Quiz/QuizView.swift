//
//  QuizView.swift
//  JelajahSolo
//
//  Created by Randy Julian on 10/04/23.
//

import SwiftUI

struct QuizView: View {
    
    @State var i : Int = 0
    @State var score = 0
    @State var scale: CGFloat = 1.0
    
    var body: some View {
        ZStack {
            
            Image("bgBatik")
                .resizable()
                .scaledToFill()
                .scaleEffect(scale)
                .animation(Animation.easeInOut(duration: 20.0).repeatForever(autoreverses: true), value: scale)
            
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
                .frame(width: 600, height: 550)
            
            VStack(){
                if(self.i < JSQuiz.count){
                    //image
                    Image(JSQuiz[self.i].img!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                        .padding()
                        .padding(.top, 20)
                    
                    //question
                    Text(JSQuiz[self.i].quest!)
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 550)
                    
                    //choice
                    Button(action: {
                        self.btnChoice(n: 0)
                    }, label: {
                        Text(JSQuiz[self.i].choice[0])
                            .foregroundColor(.white)
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: 500, alignment: .leading)
                            .background(RoundedRectangle(cornerRadius: 10)
                                .stroke(.yellow, lineWidth: 2))
                            .padding(.bottom, 10)
                    })
                    
                    Button(action: {
                        self.btnChoice(n: 1)
                    }, label: {
                        Text(JSQuiz[self.i].choice[1])
                            .foregroundColor(.white)
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: 500, alignment: .leading)
                            .background(RoundedRectangle(cornerRadius: 10)
                                .stroke(.yellow, lineWidth: 2))
                            .padding(.bottom, 10)
                    })

                    Button(action: {
                        self.btnChoice(n: 2)
                    }, label: {
                        Text(JSQuiz[self.i].choice[2])
                            .foregroundColor(.white)
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: 500, alignment: .leading)
                            .background(RoundedRectangle(cornerRadius: 10)
                                .stroke(.yellow, lineWidth: 2))
                            .padding(.bottom, 10)
                    })
                    
                    //score
                    Text("Score: [ \(self.score) / \(JSQuiz.count) ]")
                        .bold()
                        .foregroundColor(.white)
                        .padding(.bottom, 20)
                    
                    
                }
                else{
                    FinalView()
                }
            }
            .padding()
        }.onAppear{
            self.scale = 1.5
        }
    }
    
    func btnChoice(n : Int){
        if(JSQuiz[self.i].ans == n){
            self.score = self.score + 1
        }
        self.i = self.i + 1
    }
    
}

struct QuizView_Previews: PreviewProvider {
    static var previews: some View {
        QuizView()
    }
}
