//
//  Question.swift
//  JelajahSolo
//
//  Created by Randy Julian on 10/04/23.
//

import Foundation

struct Quiz{
    var img : String?
    var quest : String?
    var choice : [String]
    var ans : Int?
}

var JSQuiz : [Quiz] = [
    Quiz(img: "dawet",
         quest: "What is the name of traditional dessert that Joko likes above?",
         choice: ["Ronde", "Dawet", "Cendol"],
         ans: 1),
    
    Quiz(img: "putri2",
         quest: "What is the name of this traditional dance?",
         choice: ["Tari Serimpi", "Tari Saman", "Tari Jaipong"],
         ans: 0),
    
    Quiz(img: "dakon",
         quest: "What is the name of this traditional game?",
         choice: ["Dakon", "Kelereng", "Egrang"],
         ans: 0),
    
    Quiz(img: "gamelan",
         quest: "What is the name of the traditional musical instrument played by Bambang?",
         choice: ["Angklung", "Kolintang", "Gamelan"],
         ans: 2),
]
