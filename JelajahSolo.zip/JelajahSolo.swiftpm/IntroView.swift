//
//  IntroView.swift
//  JelajahSolo
//
//  Created by Randy Julian on 10/04/23.
//

import SwiftUI

struct IntroView: View {
    var body: some View {
        
        VStack {
            Spacer()
            ZStack(){
                
                Image("bgBatik2")
                    .resizable()
                    .opacity(0.6)
                    .scaledToFit()
                
                RoundedRectangle(cornerRadius: 20)
                    .background(.ultraThinMaterial).opacity(0.85)
                    .frame(width: 650, height: 500)
                
                
                VStack{
                    Image("title")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 100)
                    
                    
                    Text("Solo is one of the cities in Indonesia which is located on the island of Java, more precisely in Central Java. Solo also known as Surakarta (an official Administrative name).\n")
                        .italic()
                        .multilineTextAlignment(.center)
                        .font(.title2)
                    
                    
                    Text("This application aims to make you more familiar with Solo City")
                    VStack(alignment: .leading) {
                    Text("Instruction : ").bold()
                        Text("1. Get to know each of the person by clicking the button under their picture 🤩").bold()
                        Text("2. Do the knowledge quiz by clicking the button at the bottom of the page after finishing get to know each person 🤓").bold()
                        Text("3. Enjoy your journey to get more familiar with Solo City 🥳 !!").bold()
                    }
                }
                
                .frame(maxWidth: 550)
                .foregroundColor(.white)

            }

            Spacer()
        }
    }
    
}


struct IntroView_Previews: PreviewProvider {
    static var previews: some View {
        IntroView()
    }
}
